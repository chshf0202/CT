package Type;

public interface GrammarType {
}
